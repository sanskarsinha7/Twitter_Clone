1. First enter command npm install in the terminal to install all the node modules from package.json.
2. Then enter command npm start to run and it will go on the localhost:3000
3. Enter command npm install react-scripts --save in terminal if npm start shows error react-scripts not a command